		function gotoMain()
		{
			window.open("../과제main.html", "_self");
		}